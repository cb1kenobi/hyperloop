//
//  HLAppDelegate.h
//  Dynamics
//
//  Created by Bert Grantges on 9/25/13.
//  Copyright (c) 2013 Bert Grantges. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
